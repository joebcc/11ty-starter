var dpp = new Vue({
  el: '#datapainpoints',
  data: {
    message: 'Hello Vue!'
  }
})